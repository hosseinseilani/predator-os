#!/bin/bash

# Function to display the menu using Zenity with radio list
display_menu() {
    choice=$(zenity --list --radiolist --title="Menu" --column="Select" --column="Option" \
    FALSE "Update system" \
    FALSE "Upgrade packages and kernel" \
    FALSE "Upgrade Predator-OS to last" \
    FALSE "Exit")

    echo "$choice"
}

# Function to upgrade Predator-OS to last
predator_updater() {
    # Add your Predator-OS upgrade commands here
    # sudo mv /etc/apt/sources.list /etc/apt/sources.list.bk
    # echo "vm.swappiness = 0" | sudo tee -a /etc/sysctl.conf
    sudo sysctl -p
    zenity --info --text="Predator-OS upgraded to 3.2"
}

# Main script
while true; do
    choice=$(display_menu)

    case $choice in
        "Update system")
            sudo apt update
            ;;
        "Upgrade packages and kernel")
            sudo apt dist-upgrade
            ;;
        "Upgrade Predator-OS to last")
            predator_updater
            ;;
        "Exit")
            zenity --info --text="Exiting the script. Goodbye!"
            break
            ;;
        *)
            zenity --error --text="Invalid option. Please choose a valid option."
            ;;
    esac
done
